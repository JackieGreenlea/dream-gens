import { ExploreStoriesCarousel } from "@/components/home/explore-stories-carousel";

const placeholderStories = [
  {
    title: "Kedar",
    summary: "Storm-wracked ruins, buried gods, and one story waiting to be disturbed.",
    accent: "from-slate-600 via-slate-700 to-slate-900",
  },
  {
    title: "The Debugger",
    summary: "A fast-moving thriller where one impossible bug starts rewriting the city around you.",
    accent: "from-cyan-500 via-emerald-500 to-slate-900",
  },
  {
    title: "Xaxas",
    summary: "A quiet kingdom built on old bargains, now beginning to crack under pressure.",
    accent: "from-amber-500 via-stone-700 to-slate-900",
  },
  {
    title: "Procavia",
    summary: "A neon district, a sealed gate, and a night that keeps revealing the wrong future.",
    accent: "from-sky-400 via-indigo-700 to-slate-950",
  },
];

const storyRows = ["Trending", "Placeholder 2", "Placeholder 3", "Placeholder 4"];

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ message?: string }>;
}) {
  await searchParams;

  return (
    <main className="min-h-screen bg-page">
      <div className="mx-auto flex min-h-screen max-w-[1680px] flex-col gap-8 px-4 py-8 sm:px-6 lg:px-8">
        <section className="overflow-hidden rounded-[2rem] border border-line bg-surface px-6 py-20 shadow-glow sm:px-10 sm:py-24">
          <div className="mx-auto flex min-h-[230px] max-w-4xl items-center justify-center text-center">
            <div className="space-y-3">
              <h1 className="text-5xl font-semibold uppercase tracking-tight text-foreground sm:text-6xl lg:text-7xl">
                Everplot
              </h1>
              <p className="text-lg font-medium text-secondary sm:text-xl">Create. Explore. Play.</p>
            </div>
          </div>
        </section>

        <div className="space-y-8">
          {storyRows.map((rowTitle) => (
            <section key={rowTitle} className="space-y-4">
              <div className="space-y-1">
                <h2 className="text-2xl font-semibold text-foreground">{rowTitle}</h2>
                <p className="text-sm text-secondary">Placeholder cards for featured stories.</p>
              </div>

              <ExploreStoriesCarousel stories={placeholderStories} />
            </section>
          ))}
        </div>
      </div>
    </main>
  );
}
