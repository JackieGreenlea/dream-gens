"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";

type PlaceholderStory = {
  title: string;
  summary: string;
  accent: string;
};

type ExploreStoriesCarouselProps = {
  stories: PlaceholderStory[];
};

export function ExploreStoriesCarousel({ stories }: ExploreStoriesCarouselProps) {
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const [hasOverflow, setHasOverflow] = useState(false);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  useEffect(() => {
    const scroller = scrollerRef.current;

    if (!scroller) {
      return;
    }

    function updateScrollState() {
      const currentScroller = scrollerRef.current;

      if (!currentScroller) {
        return;
      }

      const overflow = currentScroller.scrollWidth > currentScroller.clientWidth + 1;

      setHasOverflow(overflow);
      setCanScrollLeft(currentScroller.scrollLeft > 1);
      setCanScrollRight(
        currentScroller.scrollLeft + currentScroller.clientWidth < currentScroller.scrollWidth - 1,
      );
    }

    updateScrollState();

    const resizeObserver = new ResizeObserver(updateScrollState);
    resizeObserver.observe(scroller);
    scroller.addEventListener("scroll", updateScrollState, { passive: true });
    window.addEventListener("resize", updateScrollState);

    return () => {
      resizeObserver.disconnect();
      scroller.removeEventListener("scroll", updateScrollState);
      window.removeEventListener("resize", updateScrollState);
    };
  }, [stories]);

  function scrollByCards(direction: "left" | "right") {
    const scroller = scrollerRef.current;

    if (!scroller) {
      return;
    }

    const amount = Math.max(scroller.clientWidth * 0.72, 280);
    scroller.scrollBy({
      left: direction === "right" ? amount : -amount,
      behavior: "smooth",
    });
  }

  return (
    <div className="relative">
      <div
        ref={scrollerRef}
        className="flex gap-4 overflow-x-auto scroll-smooth pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {stories.map((story) => (
          <Link
            key={story.title}
            href="/"
            className="block min-w-0 flex-none basis-[85%] sm:basis-[calc((100%-1rem)/2)] lg:basis-[calc((100%-2rem)/3)] xl:basis-[calc((100%-3rem)/4)]"
          >
            <Card className="flex h-full flex-col gap-4 overflow-hidden p-0 transition hover:border-fieldBorder hover:bg-elevated">
              <div className={`h-40 bg-gradient-to-br ${story.accent}`} />
              <div className="space-y-3 p-5">
                <h3 className="text-xl font-semibold text-foreground">{story.title}</h3>
                <p className="text-sm leading-6 text-secondary">{story.summary}</p>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      {hasOverflow ? (
        <>
          <button
            type="button"
            onClick={() => scrollByCards("left")}
            className={`absolute left-3 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-surface/95 text-foreground shadow-glow transition hover:border-fieldBorder hover:bg-elevated ${
              canScrollLeft ? "opacity-100" : "pointer-events-none opacity-0"
            }`}
            aria-label="Scroll stories left"
          >
            <span className="text-xl leading-none">‹</span>
          </button>

          <button
            type="button"
            onClick={() => scrollByCards("right")}
            className={`absolute right-3 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-surface/95 text-foreground shadow-glow transition hover:border-fieldBorder hover:bg-elevated ${
              canScrollRight ? "opacity-100" : "pointer-events-none opacity-0"
            }`}
            aria-label="Scroll stories right"
          >
            <span className="text-xl leading-none">›</span>
          </button>
        </>
      ) : null}
    </div>
  );
}
