export const STORY_COVER_BUCKET = "story-covers";
export const MAX_STORY_COVER_BYTES = 5 * 1024 * 1024;

export function createStoryCoverPath(params: {
  userId: string;
  storyId: string;
  fileName: string;
}) {
  const safeName = params.fileName
    .toLowerCase()
    .replace(/[^a-z0-9.]+/g, "-")
    .replace(/^-+|-+$/g, "");

  return `${params.userId}/${params.storyId}/${Date.now()}-${safeName || "cover-image"}`;
}
