"use client";

import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";

const genreTabs = [
  "FOR YOU",
  "TRENDING",
  "NEW",
  "FANTASY",
  "MAGIC",
  "ROMANCE",
  "FILM & TV",
  "ADVENTURE",
  "SLICE OF LIFE",
  "SCI-FI",
  "SUPERHERO",
  "HISTORICAL",
  "MYSTERY",
  "SUPERNATURAL",
  "COMEDY",
] as const;

const tabsWithoutSorter = new Set(["FOR YOU", "TRENDING", "NEW"]);

const placeholderStories = [
  {
    title: "Anthology",
    creator: "everplot",
    age: "8 months ago",
    description:
      "Thirty connected prompts across six genres, built as a clean starting point for readers who want variety.",
    accent: "from-amber-200 via-orange-500 to-stone-900",
    stats: ["368 likes", "2.1M plays", "2.6k saves", "70 comments"],
  },
  {
    title: "Dude, Do I Look Pretty?",
    creator: "ZestiusMaximus",
    age: "2 months ago",
    description:
      "A social comedy setup about friendship, embarrassment, and trying to survive one very cursed public outing.",
    accent: "from-rose-300 via-fuchsia-500 to-stone-800",
    stats: ["195 likes", "16k plays", "1.8k saves", "16 comments"],
  },
  {
    title: "Random Isekai!",
    creator: "YukikoHonomiko",
    age: "8 months ago",
    description:
      "Every restart drops you into a different world with different rules, enemies, and one absurd chance at survival.",
    accent: "from-sky-300 via-indigo-500 to-slate-900",
    stats: ["692 likes", "70k plays", "5.4k saves", "107 comments"],
  },
  {
    title: "Her First Victim",
    creator: "Rivaldragon",
    age: "2 months ago",
    description:
      "A dark mystery setup built around escalating suspicion, strange intimacy, and the first mistake nobody can undo.",
    accent: "from-zinc-300 via-violet-700 to-black",
    stats: ["244 likes", "21k plays", "1.1k saves", "38 comments"],
  },
];

export function ExploreBrowser() {
  const [selectedTab, setSelectedTab] = useState<(typeof genreTabs)[number]>("FOR YOU");
  const tabsScrollerRef = useRef<HTMLDivElement | null>(null);
  const [isTabsHovered, setIsTabsHovered] = useState(false);
  const [tabsHaveOverflow, setTabsHaveOverflow] = useState(false);
  const [canScrollTabsLeft, setCanScrollTabsLeft] = useState(false);
  const [canScrollTabsRight, setCanScrollTabsRight] = useState(false);

  useEffect(() => {
    const scroller = tabsScrollerRef.current;

    if (!scroller) {
      return;
    }

    function updateTabScrollState() {
      const currentScroller = tabsScrollerRef.current;

      if (!currentScroller) {
        return;
      }

      const overflow = currentScroller.scrollWidth > currentScroller.clientWidth + 1;

      setTabsHaveOverflow(overflow);
      setCanScrollTabsLeft(currentScroller.scrollLeft > 1);
      setCanScrollTabsRight(
        currentScroller.scrollLeft + currentScroller.clientWidth < currentScroller.scrollWidth - 1,
      );
    }

    updateTabScrollState();

    const resizeObserver = new ResizeObserver(updateTabScrollState);
    resizeObserver.observe(scroller);
    scroller.addEventListener("scroll", updateTabScrollState, { passive: true });
    window.addEventListener("resize", updateTabScrollState);

    return () => {
      resizeObserver.disconnect();
      scroller.removeEventListener("scroll", updateTabScrollState);
      window.removeEventListener("resize", updateTabScrollState);
    };
  }, []);

  function scrollTabs(direction: "left" | "right") {
    const scroller = tabsScrollerRef.current;

    if (!scroller) {
      return;
    }

    const amount = Math.max(scroller.clientWidth * 0.6, 220);
    scroller.scrollBy({
      left: direction === "right" ? amount : -amount,
      behavior: "smooth",
    });
  }

  return (
    <div className="space-y-6">
      <section className="space-y-4">
        <div
          className="relative"
          onMouseEnter={() => setIsTabsHovered(true)}
          onMouseLeave={() => setIsTabsHovered(false)}
        >
          <div
            ref={tabsScrollerRef}
            className="flex gap-3 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {genreTabs.map((tab) => {
              const isActive = tab === selectedTab;

              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setSelectedTab(tab)}
                  className={`shrink-0 rounded-2xl border px-5 py-3 text-md font-bold tracking-[0.08em] transition ${
                    isActive
                      ? "border-warm bg-warm text-page"
                      : "border-line bg-surface text-foreground hover:border-fieldBorder hover:bg-elevated"
                  }`}
                >
                  {tab}
                </button>
              );
            })}
          </div>

          {tabsHaveOverflow ? (
            <>
              <button
                type="button"
                onClick={() => scrollTabs("left")}
                className={`absolute left-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-surface/95 text-foreground shadow-glow transition hover:border-fieldBorder hover:bg-elevated ${
                  isTabsHovered && canScrollTabsLeft ? "opacity-100" : "pointer-events-none opacity-0"
                }`}
                aria-label="Scroll genres left"
              >
                <span className="text-xl leading-none">‹</span>
              </button>

              <button
                type="button"
                onClick={() => scrollTabs("right")}
                className={`absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-surface/95 text-foreground shadow-glow transition hover:border-fieldBorder hover:bg-elevated ${
                  isTabsHovered && canScrollTabsRight ? "opacity-100" : "pointer-events-none opacity-0"
                }`}
                aria-label="Scroll genres right"
              >
                <span className="text-xl leading-none">›</span>
              </button>
            </>
          ) : null}
        </div>

        {!tabsWithoutSorter.has(selectedTab) ? (
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              className="rounded-2xl border border-line bg-surface px-4 py-2.5 text-sm font-medium text-secondary transition hover:border-fieldBorder hover:bg-elevated hover:text-foreground"
            >
              Sort: Most Played
            </button>
          </div>
        ) : null}
      </section>

      <section className="space-y-4">
        {placeholderStories.map((story) => (
          <Card
            key={story.title}
            className="overflow-hidden p-0"
          >
            <div className="grid min-h-[260px] grid-cols-1 md:grid-cols-[280px_minmax(0,1fr)] xl:grid-cols-[380px_minmax(0,1fr)_160px]">
              <div className={`min-h-[220px] bg-gradient-to-br ${story.accent}`} />

              <div className="flex flex-col justify-between gap-6 p-6">
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-3 text-sm text-secondary">
                    <span className="font-medium text-foreground">{story.creator}</span>
                    <span>{story.age}</span>
                  </div>
                  <h2 className="text-3xl font-semibold text-foreground">{story.title}</h2>
                  <p className="max-w-4xl text-base leading-8 text-secondary">{story.description}</p>
                </div>

                <div className="flex flex-wrap gap-4 text-sm text-muted">
                  {story.stats.map((stat) => (
                    <span key={stat}>{stat}</span>
                  ))}
                </div>
              </div>

              <div className="flex items-end justify-start p-6 xl:items-center xl:justify-end">
                <button
                  type="button"
                  className="rounded-2xl border border-line bg-surface px-6 py-3 text-sm font-semibold uppercase tracking-[0.08em] text-foreground transition hover:border-fieldBorder hover:bg-elevated"
                >
                  Play
                </button>
              </div>
            </div>
          </Card>
        ))}
      </section>
    </div>
  );
}
