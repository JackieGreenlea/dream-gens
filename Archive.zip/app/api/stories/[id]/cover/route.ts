import { NextResponse } from "next/server";
import { updateStoryCoverImageForUser } from "@/lib/db";
import { STORY_COVER_BUCKET, MAX_STORY_COVER_BYTES, createStoryCoverPath } from "@/lib/supabase/storage";
import { createClient, getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";

const ALLOWED_IMAGE_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);

export async function POST(
  request: Request,
  context: {
    params: Promise<{ id: string }>;
  },
) {
  const { id } = await context.params;
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json({ error: "Sign in to upload a story cover." }, { status: 401 });
  }

  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Choose an image file to upload." }, { status: 400 });
  }

  if (!ALLOWED_IMAGE_TYPES.has(file.type)) {
    return NextResponse.json({ error: "Upload a JPG, PNG, WEBP, or GIF image." }, { status: 400 });
  }

  if (file.size > MAX_STORY_COVER_BYTES) {
    return NextResponse.json({ error: "Image must be 5MB or smaller." }, { status: 400 });
  }

  const supabase = await createClient();
  const path = createStoryCoverPath({
    userId: user.id,
    storyId: id,
    fileName: file.name,
  });

  const { error: uploadError } = await supabase.storage
    .from(STORY_COVER_BUCKET)
    .upload(path, file, {
      contentType: file.type,
      cacheControl: "3600",
      upsert: false,
    });

  if (uploadError) {
    return NextResponse.json(
      { error: uploadError.message || "The story cover could not be uploaded." },
      { status: 502 },
    );
  }

  const {
    data: { publicUrl },
  } = supabase.storage.from(STORY_COVER_BUCKET).getPublicUrl(path);

  const story = await updateStoryCoverImageForUser(id, user.id, publicUrl);

  if (!story) {
    return NextResponse.json({ error: "Story not found." }, { status: 404 });
  }

  return NextResponse.json({ story });
}
